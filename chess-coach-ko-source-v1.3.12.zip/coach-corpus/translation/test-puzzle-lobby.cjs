const fs=require('node:fs'),assert=require('node:assert/strict');
const {JSDOM}=require('./test-deps/node_modules/jsdom');
const script=fs.readFileSync(__dirname+'/coaches-ko.user.js','utf8');
const source='In every Puzzle position, only one move works...\nCan you find it?';
const expected='각 퍼즐에는 정답인 수가 딱 하나 있습니다... 찾을 수 있나요?';
(async()=>{for(const coach of ['Hikaru','Magnus']){
 const dom=new JSDOM(`<div class="bot-speech-avatar-and-wrapper-component"><img class="bot-speech-avatar-and-wrapper-botImage" alt="${coach}"><div class="bot-speech-content-botMessage"><span class="typewriter-text-tw"></span></div></div><p id="outside"></p>`,{url:'https://www.chess.com/puzzles',runScripts:'outside-only'});
 const w=dom.window,d=w.document,original=d.querySelector('.typewriter-text-tw');
 Object.defineProperty(w.HTMLElement.prototype,'getClientRects',{value:()=>[{}]});
 try{
 original.textContent=source;d.querySelector('#outside').textContent=source;w.eval(script);
 await new Promise(r=>setTimeout(r,250));
 assert.equal(d.querySelector('.mko-translation > span')?.textContent,expected);
 assert(original.classList.contains('mko-source-hidden'));assert.equal(original.textContent,source);
 assert(!d.querySelector('.mko-toggle').textContent.includes('EN 1'));
 assert.equal(d.querySelector('#outside').textContent,source);assert.equal(d.querySelector('#outside').children.length,0);
 original.textContent="Welcome back! Let's get solving...";
 await new Promise(r=>setTimeout(r,250));
 assert.equal(d.querySelector('.mko-translation > span')?.textContent,'다시 오셨군요! 퍼즐을 풀어봅시다...');
 }finally{w.close();}
}console.log('PASS puzzle lobby: screenshot text, line break, dynamic replacement and untouched outside text for both coaches.');})().catch(e=>{console.error(e);process.exitCode=1;});
