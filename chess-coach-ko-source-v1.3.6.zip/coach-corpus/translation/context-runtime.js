function coachScreenContext(el) {
  const path=location.pathname;
  const visible=e=>!!e?.getClientRects().length;
  const has=selector=>[...document.querySelectorAll(selector)].some(visible);
  const surface=el?.closest('.move-feedback-component')?'move_feedback':el?.closest('.coach-selection-controller-messages')?'coach_setup':el?.closest('.bot-speech-multiple-messages-component')?'coach_chat':'speech_bubble';
  let page='unknown',playType='unknown',phase='unknown',screenEvidence='unavailable';
  if(/^\/play\/coach(?:\/|$)/.test(path)) {
    page='coach_play';playType='vs_coach';phase=surface==='coach_setup'?'setup':'unknown';screenEvidence='route:play/coach';
  } else if(/^\/play\/computer(?:\/|$)/.test(path)) {page='computer_play';playType='vs_computer';screenEvidence='route:play/computer';}
  else if(/^\/play\/online(?:\/|$)/.test(path)) {page='online_play';playType='online';screenEvidence='route:play/online';}
  else if(/^\/puzzles(?:\/|$)/.test(path)) {
    page='puzzle';playType=/^\/puzzles\/rated(?:\/|$)/.test(path)?'rated_puzzle':/^\/puzzles\/rush(?:\/|$)/.test(path)?'puzzle_rush':/^\/puzzles\/battle(?:\/|$)/.test(path)?'puzzle_battle':'puzzle_other';screenEvidence='route:puzzles';
  } else if(/^\/analysis(?:\/|$)/.test(path)) {
    const review=/\/review(?:\/|$)/.test(path) || has('.move-by-move-coach-section') || [...document.querySelectorAll('h1')].some(e=>visible(e)&&['게임 리뷰','Game Review'].includes(e.textContent.trim()));
    page=review?'game_review':'analysis';phase=surface==='move_feedback'?'move_feedback':'unknown';screenEvidence=review?'review_route_or_move_panel':'route:analysis';
    const type=path.match(/^\/analysis\/game\/(live|daily|computer|coach)(?:\/|$)/)?.[1];
    playType=type==='live'?'online_live':type==='daily'?'daily':type==='computer'?'vs_computer':type==='coach'?'vs_coach':'unknown';
  } else if(/^\/game\/(live|daily)(?:\/|$)/.test(path)) {
    page='game';playType=path.startsWith('/game/live/')?'online_live':'daily';screenEvidence='route:game';
  } else if(/^\/play(?:\/|$)/.test(path)){page='play_other';screenEvidence='route:play';}
  // Only fixed, observed UI labels are inspected. No player names are stored.
  const labels=[...document.querySelectorAll('button')].filter(visible).map(e=>(e.textContent||'').trim());
  if(['analysis','game_review'].includes(page) && ['unknown','vs_computer'].includes(playType) && [...document.querySelectorAll('[data-test-element="user-tagline-username"]')].some(e=>visible(e)&&/^(Magnus|Hikaru) (코치님|Coach)$/.test((e.textContent||'').trim()))) {
    playType='vs_coach';screenEvidence+=';visible_coach_player_label';
  }
  if(el?.closest('.game-over-coach-speech-slot-component,.game-over-modal-shell-content')){phase='game_over';screenEvidence+=';game_over_modal';}
  else if(['coach_play','computer_play','online_play','game'].includes(page) && labels.some(s=>s==='기권'||s==='Resign')){phase='in_game';screenEvidence+=';resign_control';}
  if(page==='game_review' && phase==='unknown' && labels.some(s=>s==='리뷰 시작'||s==='Start Review'))phase='summary';
  const whole=el?.closest('[whole-move-number]')?.getAttribute('whole-move-number');
  const move=new URL(location.href).searchParams.get('move');
  const hints=[];
  if(whole && /^\d{1,4}$/.test(whole))hints.push('UI full move='+whole);
  if(move!==null && /^\d{1,4}$/.test(move))hints.push('URL move='+move);
  return {page,playType,phase,messageSurface:surface,screenEvidence,moveHint:hints.join('; ')||'unavailable'};
}
