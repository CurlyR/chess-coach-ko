(() => {
  'use strict';
  const packages = /* DICTIONARY */;
  const fragmentPackages = /* FRAGMENTS */;
  const dictionaries = Object.fromEntries(Object.entries(packages).map(([name,p])=>[name,new Map(p.entries.map(([en,ko,reviewed])=>[en,{ko,reviewed}]))]));
  const blocked = Object.fromEntries(Object.entries(packages).map(([name,p])=>[name,new Map(p.blocked)]));
  const normalize = s => s.normalize('NFC').replace(/\*/g,'').replace(/[‘’]/g,"'").replace(/[“”]/g,'"').replace(/\s+/g,' ').trim();
  /* REPORTER */
  /* CONTEXT */
  const reporting=createCoachReporter('1.3.9');
  const records = new Map();
  let enabled = true, scheduled = false;
  const css = document.createElement('style');
  css.textContent = '.mko-source-hidden{display:none!important}.mko-translation{display:block;white-space:normal;line-height:1.55;overflow-wrap:anywhere;font:inherit;color:inherit;text-align:inherit}.mko-toggle{position:fixed;right:10px;bottom:10px;z-index:99999;max-width:calc(100vw - 20px);border:1px solid #555;border-radius:5px;background:#292929;color:#bbb;padding:4px 7px;font:10px/13px sans-serif;cursor:pointer;opacity:.65;transition:opacity .15s}.mko-toggle:hover,.mko-toggle:focus-visible{opacity:1;color:#fff}.mko-original{font-size:11px;opacity:.8;margin-left:8px;background:none;color:inherit;border:0;text-decoration:underline;cursor:pointer}';
  document.head.append(css);
  const toggle = document.createElement('button');
  toggle.className = 'mko-toggle';
  toggle.type = 'button';
  toggle.title = '매그너스·히카루 한국어 · 검수 전 기계번역 포함. 클릭하면 원문으로 전환합니다.';
  document.body.append(toggle);
  const diagnostics=document.createElement('button');diagnostics.type='button';diagnostics.className='mko-toggle';diagnostics.style.bottom='37px';diagnostics.textContent='미번역 저장 (0)';
  diagnostics.title='오류 기록과 비공개 시트 자동 전송 설정';
  document.body.append(diagnostics);
  diagnostics.addEventListener('click',()=>reporting.panel());
  toggle.addEventListener('click',()=>{enabled=!enabled; refresh();});
  const active = () => /^\/(analysis|puzzles|play|daily)(\/|$)/.test(location.pathname) || /^\/game\/(?:(live|daily)\/|\d+(?:\/|$))/.test(location.pathname);
  let coachEvidence='unavailable';
  function selectedCoach(el) {
    coachEvidence='unavailable';
    const root=el?.closest('.bot-speech-avatar-and-wrapper-component')||document;
    const images=[...root.querySelectorAll('img.bot-speech-avatar-and-wrapper-botImage')].filter(img=>img.getClientRects().length);
    if(images.length) {
      for(const name of ['Magnus','Hikaru']) if(images.some(img=>img.alt.toLowerCase()===name.toLowerCase() || new RegExp('/coach'+name.toLowerCase()+'\\.png(?:\\?|$)').test(img.src))) {coachEvidence='avatar_image';return name;}
      return null;
    }
    const animated=[...root.querySelectorAll('.bot-speech-avatar-and-wrapper-botImage canvas')].some(canvas=>canvas.getClientRects().length);
    if(!animated)return null;
    if(/^\/play\/coach(?:\/|$)/.test(location.pathname)) {
      const names=[...document.querySelectorAll('[data-test-element="user-tagline-username"]')].filter(e=>e.getClientRects().length).map(e=>(e.textContent||'').trim()).filter(s=>/^(Magnus|Hikaru) (코치님|Coach)$/.test(s));
      if(names.length===1){coachEvidence='visible_coach_label';return names[0].split(' ')[0];}
    }
    // The animated avatar has no name in its DOM. Chess.com's resource cache
    // contains the committed currentCoach (the selection dialog is only a
    // pending preview, so never use its highlighted option as confirmation).
    // Only accept a resource refreshed during THIS page visit. Old account
    // caches and historical coach selections must not identify today's coach.
    try {
      const fresh=[];
      for(let i=0;i<localStorage.length;i++) {
        const key=localStorage.key(i);
        if(!/^Resource\.[^.]+\.coachesService\.currentCoach$/.test(key||''))continue;
        let resource;try{resource=JSON.parse(localStorage.getItem(key));}catch(_){continue;}
        if(!Number.isFinite(resource?.timestamp) || resource.timestamp<performance.timeOrigin || resource.timestamp>Date.now()+5000)continue;
        const current=resource.data?.currentCoach;
        if(!current || typeof current.name!=='string')continue;
        fresh.push(current.name);
      }
      if(fresh.length===1) {
        coachEvidence='current_coach_resource';
        return ['Magnus','Hikaru'].includes(fresh[0])?fresh[0]:null;
      }
    } catch(_) { /* Storage can be disabled; keep the conservative fallback. */ }
    coachEvidence='canvas_identity_unavailable';
    return 'Unknown';
  }
  function exactLookup(source,coach) {
    const names=coach==='Unknown'?['Magnus','Hikaru']:[coach];
    const found=names.map(n=>dictionaries[n]?.get(source)).filter(Boolean);
    if(found.length && found.every(e=>e.ko===found[0].ko))return {entry:found[0]};
    if(found.length)return {reason:'coach_unknown_conflicting_translations'};
    const reasons=names.flatMap(n=>blocked[n]?.get(source)||[]);
    return {reason:reasons.length?'excluded: '+[...new Set(reasons)].join(', '):'not_in_dictionary_or_composed_sentence'};
  }
  const segmenter=typeof Intl.Segmenter==='function'?new Intl.Segmenter('en',{granularity:'sentence'}):null;
  function lookupUnit(source,coach) {
    const exact=exactLookup(source,coach);
    if(exact.entry?.reviewed)return exact;
    const names=coach==='Unknown'?['Magnus','Hikaru']:[coach];
    const found=[];
    for(const name of names) {
      const pack=fragmentPackages[name];if(!pack)continue;
      for(const [prefix,template] of Object.entries(pack.prefixes)) {
        if(!source.startsWith(prefix+' '))continue;
        const tail=source.slice(prefix.length+1);
        if(!Object.hasOwn(pack.tails,tail))continue;
        const action=pack.tails[tail];
        const stem=action.slice(0,-1),last=stem.charCodeAt(stem.length-1),jong=(last-44032)%28;
        const future=jong?stem+'을':stem.slice(0,-1)+String.fromCharCode(last+8);
        found.push(template.replaceAll('{action}',action).replaceAll('{future}',future));
      }
    }
    if(found.length && found.every(ko=>ko===found[0]))return {entry:{ko:found[0],reviewed:true}};
    if(found.length)return {reason:'coach_unknown_conflicting_fragments'};
    return exact;
  }
  function lookup(source,coach) {
    const exact=lookupUnit(source,coach);
    if(exact.entry || exact.reason!=='not_in_dictionary_or_composed_sentence' || !segmenter)return exact;
    const parts=[...segmenter.segment(source)].map(p=>normalize(p.segment));
    if(parts.length<2)return exact;
    // Reviewed dictionary entries can contain several sentences. Match complete
    // adjacent spans, not only single sentences, without accepting partial text.
    const joined=new Array(parts.length+1);joined[parts.length]=[];
    for(let start=parts.length-1;start>=0;start--) {
      for(let end=parts.length;end>start;end--) {
        if(!joined[end] || !/[.!?]["')]*$/.test(parts[end-1]))continue;
        const hit=lookupUnit(parts.slice(start,end).join(' '),coach).entry;
        if(hit?.reviewed){joined[start]=[hit.ko,...joined[end]];break;}
      }
    }
    if(joined[0])return {entry:{ko:joined[0].join(' '),reviewed:true}};
    // Compose only complete, individually reviewed sentences. Any missing,
    // ambiguous or unreviewed component leaves the entire original visible.
    const results=parts.map(part=>/[.!?]["')]*$/.test(part)?lookupUnit(part,coach):{reason:'incomplete_sentence'});
    const entries=results.map(r=>r.entry);
    if(entries.every(entry=>entry?.reviewed))return {entry:{ko:entries.map(entry=>entry.ko).join(' '),reviewed:true}};
    return {reason:'composition: '+[...new Set(results.map(r=>r.entry?(r.entry.reviewed?'reviewed':'unreviewed_component'):r.reason))].join(', ')};
  }
  function reset(el,r) { el.classList.remove('mko-source-hidden');r.view.remove();records.delete(el); }
  function renderText(target,text) {
    // Never interpret translations as HTML.
    const pieces=text.split(/(\*[^*]+\*)/g);
    for(const piece of pieces) {
      if(piece.startsWith('*') && piece.endsWith('*') && piece.length>2) {const b=document.createElement('strong');b.textContent=piece.slice(1,-1);target.append(b);}
      else target.append(document.createTextNode(piece));
    }
  }
  function refresh() {
    scheduled=false;
    const coach=selectedCoach(),allowed=active() && !!coach;
    toggle.hidden=!active();
    diagnostics.hidden=!active();
    for (const [el,r] of records) if(!el.isConnected || !active() || !enabled || selectedCoach(el)!==r.coach || normalize(el.textContent)!==r.source) reset(el,r);
    let matched=0,missed=0;
    if(allowed && enabled) {
      // Hide only the typewriter text. The enclosing botMessage owns the
      // bubble's white background, padding, width and pointer alignment.
      const candidates=[...document.querySelectorAll('.move-feedback-speech-text-component .move-feedback-speech-text-tw, .bot-speech-content-botMessage .typewriter-text-tw')];
      for(const el of candidates) {
        if(!(el.getClientRects().length || (el.classList.contains('mko-source-hidden') && el.parentElement?.getClientRects().length)))continue;
        const coach=selectedCoach(el);
        if(!coach)continue;
        const source=normalize(el.textContent),result=lookup(source,coach),entry=result.entry;
        reporting.observe(el,source,coach,entry,result.reason,coachEvidence);
        if(records.has(el)) {matched++;continue;}
        if(!entry) {if(/[a-zA-Z]{3}/.test(source))missed++;continue;}
        const view=document.createElement('span');view.className='mko-translation';view.lang='ko';
        const text=document.createElement('span');renderText(text,entry.ko);view.append(text);
        const original=document.createElement('button');original.type='button';original.className='mko-original';original.textContent='원문';
        original.title=entry.reviewed?'원문·번역 대조 검수됨':'기계번역 초안 · 의미 오류가 남을 수 있습니다';
        let showOriginal=false;
        original.addEventListener('click',()=>{showOriginal=!showOriginal;text.replaceChildren();renderText(text,showOriginal?el.textContent:entry.ko);original.textContent=showOriginal?'한국어':'원문';});
        const report=document.createElement('button');report.type='button';report.className='mko-original';report.textContent='신고';report.title='번역 또는 표시 오류를 상황과 함께 기록합니다';
        const evidence=coachEvidence;
        report.addEventListener('click',()=>reporting.openReport(el,source,{...entry,ko:text.textContent},coach,evidence,()=>{report.textContent='기록됨';report.disabled=true;}));
        view.append(original,report);el.after(view);el.classList.add('mko-source-hidden');records.set(el,{source,view,coach});matched++;
      }
    }
    const status=!allowed?'코치 말풍선 대기':!enabled?'원문 보기':matched?'한국어 표시 중':'일치 문구 대기';
    const caption=(coach==='Hikaru'?'히카루':coach==='Magnus'?'매그너스':'코치')+' KO 1.3.9 · '+(!allowed?'대기':!enabled?'끔':matched?'켬':'대기')+(missed?' · EN '+missed:'');
    if(toggle.textContent!==caption) toggle.textContent=caption;
    toggle.title='v1.3.9 · '+status+' · 클릭하면 한국어 표시를 켜거나 끕니다.';
    const diagnosticText=reporting.status();
    if(diagnostics.textContent!==diagnosticText)diagnostics.textContent=diagnosticText;
    toggle.setAttribute('aria-pressed',String(enabled));
  }
  const observer=new MutationObserver(()=>{if(!scheduled){scheduled=true;setTimeout(refresh,120);}});
  observer.observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['src','alt']});
  setInterval(refresh,1000);
  refresh();
})();
