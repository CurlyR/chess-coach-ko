const fs=require('node:fs'),assert=require('node:assert/strict');
const {JSDOM}=require('./test-deps/node_modules/jsdom');
const code=fs.readFileSync(__dirname+'/context-runtime.js','utf8');
function inspect(path,html='<span id="speech"></span>'){
  const dom=new JSDOM(html,{url:'https://www.chess.com'+path,runScripts:'outside-only'});
  Object.defineProperty(dom.window.HTMLElement.prototype,'getClientRects',{value:()=>[{}]});
  dom.window.eval(code);const c=dom.window.coachScreenContext(dom.window.document.querySelector('#speech'));dom.window.close();return c;
}
assert.equal(inspect('/play/coach','<div class="coach-selection-controller-messages"><span id="speech"></span></div>').phase,'setup');
assert.equal(inspect('/play/coach').playType,'vs_coach');
assert.equal(inspect('/play/computer').playType,'vs_computer');
assert.equal(inspect('/play/online').page,'online_play');
assert.equal(inspect('/analysis').page,'analysis');
assert.equal(inspect('/analysis','<h1>게임 리뷰</h1><span id="speech"></span>').page,'game_review');
const review=inspect('/analysis/game/live/PRIVATE/review?move=9&username=PRIVATE','<div class="move-feedback-component"><div whole-move-number="5"><span id="speech"></span></div></div>');
assert.equal(review.playType,'online_live');assert.equal(review.phase,'move_feedback');assert.equal(review.moveHint,'UI full move=5; URL move=9');assert(!JSON.stringify(review).includes('PRIVATE'));
assert.equal(inspect('/analysis/game/coach/PRIVATE/review').playType,'vs_coach');
assert.equal(inspect('/analysis','<h1>게임 리뷰</h1><div data-test-element="user-tagline-username">Hikaru 코치님</div><span id="speech"></span>').playType,'vs_coach');
assert.equal(inspect('/analysis/game/live/PRIVATE/review','<button>리뷰 시작</button><span id="speech"></span>').phase,'summary');
assert.equal(inspect('/game/live/PRIVATE','<div class="game-over-coach-speech-slot-component"><span id="speech"></span></div>').phase,'game_over');
assert.equal(inspect('/puzzles/rated').playType,'rated_puzzle');
const numeric=inspect('/game/123456789','<div class="game-over-coach-speech-slot-component"><span id="speech"></span></div>');
assert.equal(numeric.page,'game');assert.equal(numeric.playType,'online');assert.equal(numeric.phase,'game_over');
assert(!JSON.stringify(numeric).includes('123456789'));
assert.equal(inspect('/puzzles/rush').playType,'puzzle_rush');
assert.equal(inspect('/play/coach','<button>기권</button><span id="speech"></span>').phase,'in_game');
assert.equal(inspect('/play/coach').phase,'unknown','do not guess game activity from URL alone');
console.log('PASS context: play types, review vs analysis, summary/move/end/setup phases, move evidence, no full URLs or identity.');
