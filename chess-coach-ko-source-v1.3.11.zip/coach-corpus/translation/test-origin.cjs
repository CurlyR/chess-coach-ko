const fs=require('node:fs'),assert=require('node:assert/strict');
const {JSDOM}=require('./test-deps/node_modules/jsdom');
const inputs=require('./origin-sources.json'),approved=require('./reviewed-origin-overrides.json');
assert.equal(inputs.loading.length,31);assert.equal(inputs.coachChanges.length,19);
for(const source of [...inputs.loading,...inputs.coachChanges.map(r=>r.source)])assert(approved[source],source);
const script=fs.readFileSync(__dirname+'/coaches-ko.user.js','utf8');
const dom=new JSDOM('<img class="bot-speech-avatar-and-wrapper-botImage" alt="Hikaru">',{url:'https://www.chess.com/game/123456789',runScripts:'outside-only'});
const w=dom.window,d=w.document;Object.defineProperty(w.HTMLElement.prototype,'getClientRects',{value:()=>[{}]});
const cases=Object.entries(approved).map(([source,expected])=>({source,expected}));
for(const {source} of inputs.coachChanges)cases.push({source:source+' 연속으로 8개를 맞추었습니다!',expected:approved[source]+' 연속으로 8개를 맞추었습니다!'});
const samples=cases.map(({source,expected})=>{const shell=d.createElement('div');shell.className='bot-speech-content-botMessage';const original=d.createElement('span');original.className='typewriter-text-tw';original.textContent=source;shell.append(original);d.body.append(shell);return{source,expected,shell,original};});
(async()=>{w.eval(script);for(const coach of ['Hikaru','Magnus']){d.querySelector('img').alt=coach;await new Promise(r=>setTimeout(r,400));for(const {source,expected,shell,original} of samples){assert.equal(shell.querySelector('.mko-translation > span')?.textContent,expected,coach+': '+source);assert(original.classList.contains('mko-source-hidden'));assert.equal(original.textContent,source);assert.equal(shell.querySelector('.mko-original').title,'원문·번역 대조 검수됨');}}
console.log(`PASS origins: all 31 loading texts, 19 coach changes, original puzzle phrase and 19 mixed-locale compositions; exact Korean and reviewed status verified for both coaches.`);w.close();})().catch(e=>{console.error(e);w.close();process.exitCode=1;});
