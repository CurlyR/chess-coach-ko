const fs=require('node:fs'),path=require('node:path');
const root=__dirname;
const normalize=s=>s.normalize('NFC').replace(/\*/g,'').replace(/[‘’]/g,"'").replace(/[“”]/g,'"').replace(/\s+/g,' ').trim();
const overrides={...JSON.parse(fs.readFileSync(path.join(root,'reviewed-loading-overrides.json'),'utf8')),...JSON.parse(fs.readFileSync(path.join(root,'reviewed-common-overrides.json'),'utf8')),...JSON.parse(fs.readFileSync(path.join(root,'userscript-overrides.json'),'utf8')),...JSON.parse(fs.readFileSync(path.join(root,'observed-overrides.json'),'utf8'))};
Object.assign(overrides,JSON.parse(fs.readFileSync(path.join(root,'reviewed-home-overrides.json'),'utf8')));
Object.assign(overrides,JSON.parse(fs.readFileSync(path.join(root,'reviewed-audit-overrides.json'),'utf8')));
Object.assign(overrides,require('./reviewed-puzzle-families.cjs'));
Object.assign(overrides,JSON.parse(fs.readFileSync(path.join(root,'reviewed-nov20-overrides.json'),'utf8')));
Object.assign(overrides,require('./expand-reviewed-colors.cjs'));
Object.assign(overrides,JSON.parse(fs.readFileSync(path.join(root,'reviewed-full-pass-overrides.json'),'utf8')));
Object.assign(overrides,JSON.parse(fs.readFileSync(path.join(root,'reviewed-nov24-overrides.json'),'utf8')));
const fragments=require('./build-fragments.cjs');
Object.assign(overrides,JSON.parse(fs.readFileSync(path.join(root,'reviewed-nov26-overrides.json'),'utf8')));
Object.assign(overrides,JSON.parse(fs.readFileSync(path.join(root,'reviewed-origin-overrides.json'),'utf8')));
const packages={},report={version:'1.3.11',coaches:{},uiTested:false};
for(const coach of ['Magnus','Hikaru']){
 const file=path.join(root,coach+'_coach.ko.jsonl');
 const rows=fs.existsSync(file)?fs.readFileSync(file,'utf8').trim().split(/\r?\n/).filter(Boolean).map(JSON.parse):[];
 const dict=new Map(),blocked=new Map(),collisions=new Set();
 for(const r of rows){
  const key=normalize(r.source),reasons=[...(r.issues||[])];
  if(r.status==='needs_context_review')reasons.push('context_review');
  if(!/[가-힣]/.test(r.ko))reasons.push('no_korean');
  if(/%[a-zA-Z_]+%|\{[^}]+\}/.test(r.source))reasons.push('dynamic_template');
  if(reasons.length){blocked.set(key,[...new Set(reasons)]);continue;}
  const entry={ko:r.ko,reviewed:r.status==='source_and_key_reviewed'};
  const prev=dict.get(key);
  if(prev && prev.ko!==r.ko){
   if(entry.reviewed&&!prev.reviewed){dict.set(key,entry);collisions.delete(key);}
   else if(!prev.reviewed||entry.reviewed)collisions.add(key);
  }else dict.set(key,entry);
 }
 for(const key of collisions){dict.delete(key);blocked.set(key,['ambiguous_translation']);}
 for(const [source,ko] of Object.entries(overrides)) {const key=normalize(source);dict.set(key,{ko,reviewed:true});blocked.delete(key);}
 for(const key of dict.keys())blocked.delete(key);
 packages[coach]={entries:[...dict].map(([s,r])=>[s,r.ko,r.reviewed]),blocked:[...blocked]};
 report.coaches[coach]={translatedRows:rows.length,enabled:dict.size,excludedKeys:blocked.size,reviewed:[...dict.values()].filter(r=>r.reviewed).length};
}
const header=`// ==UserScript==
// @name         Chess.com 매그너스 한국어 말풍선
// @namespace    local.chess-coach-ko
// @version      1.3.11
// @updateURL    https://raw.githubusercontent.com/CurlyR/chess-coach-ko/main/coaches-ko.meta.js
// @downloadURL  https://raw.githubusercontent.com/CurlyR/chess-coach-ko/main/coaches-ko.user.js
// @description  매그너스·히카루 한국어 말풍선 및 미번역 진단. 로컬 사전 사용.
// @match        https://www.chess.com/*
// @run-at       document-idle
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_listValues
// @grant        GM_xmlhttpRequest
// @grant        GM_registerMenuCommand
// @connect      script.google.com
// @connect      script.googleusercontent.com
// @noframes
// ==/UserScript==\n`;
const script=header+fs.readFileSync(path.join(root,'userscript-runtime.js'),'utf8').replace('/* DICTIONARY */',()=>JSON.stringify(packages)).replace('/* FRAGMENTS */',()=>JSON.stringify(fragments)).replace('/* REPORTER */',()=>fs.readFileSync(path.join(root,'reporter-runtime.js'),'utf8')).replace('/* CONTEXT */',()=>fs.readFileSync(path.join(root,'context-runtime.js'),'utf8'));
for(const file of ['coaches-ko.user.js','magnus-ko.user.js'])fs.writeFileSync(path.join(root,file),script);
const obs=JSON.parse(fs.readFileSync(path.join(root,'../observations.json'),'utf8'));
const known=new Set(packages.Magnus.entries.map(x=>x[0]));
report.observedReviewCoverage={total:obs.length,exactMatches:obs.filter(o=>known.has(normalize(o.text))).length};
const received=JSON.parse(fs.readFileSync(path.join(root,'received-untranslated-2026-11-18.json'),'utf8'));
report.homeLogCoverage={total:received.length,exactMatches:received.filter(r=>['Magnus','Hikaru'].every(n=>packages[n].entries.some(e=>e[0]===normalize(r.source)&&e[2]))).length};
fs.writeFileSync(path.join(root,'userscript-report.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify(report));
require('node:child_process').execFileSync(process.execPath,[path.join(root,'test-userscript.cjs')],{stdio:'inherit'});
require('node:child_process').execFileSync(process.execPath,[path.join(root,'test-reporter.cjs')],{stdio:'inherit'});
require('node:child_process').execFileSync(process.execPath,[path.join(root,'test-context.cjs')],{stdio:'inherit'});
require('node:child_process').execFileSync(process.execPath,[path.join(root,'test-full-review.cjs')],{stdio:'inherit'});
require('node:child_process').execFileSync(process.execPath,[path.join(root,'test-common-review.cjs')],{stdio:'inherit'});
require('node:child_process').execFileSync(process.execPath,[path.join(root,'test-fragments.cjs')],{stdio:'inherit'});
require('node:child_process').execFileSync(process.execPath,[path.join(root,'test-daily.cjs')],{stdio:'inherit'});
require('node:child_process').execFileSync(process.execPath,[path.join(root,'test-nov26.cjs')],{stdio:'inherit'});
require('node:child_process').execFileSync(process.execPath,[path.join(root,'test-origin.cjs')],{stdio:'inherit'});
fs.writeFileSync(path.join(root,'installer-ready.json'),JSON.stringify({state:'built_and_tested',version:'1.3.11',coaches:report.coaches,builtAt:new Date().toISOString()},null,2));

const release=path.join(root,'release');fs.mkdirSync(release,{recursive:true});
fs.writeFileSync(path.join(release,'coaches-ko.user.js'),script);
fs.writeFileSync(path.join(release,'coaches-ko.meta.js'),header);
fs.copyFileSync(path.join(root,'release-readme.txt'),path.join(release,'README.md'));
