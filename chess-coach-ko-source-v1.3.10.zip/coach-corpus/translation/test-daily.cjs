const fs=require('node:fs'),assert=require('node:assert/strict');
const {JSDOM}=require('./test-deps/node_modules/jsdom');
const script=fs.readFileSync(__dirname+'/coaches-ko.user.js','utf8');
const html=`<div class="bot-speech-avatar-and-wrapper-component"><img class="bot-speech-avatar-and-wrapper-botImage" alt="Hikaru"><div class="bot-speech-content-botMessage" style="background:white"><div class="daily-puzzle-message-component" data-message-type="solved"><div class="coach-feedback-detail-text"><span class="typewriter-text-tw">해결 되었습니다</span></div><p><span class="typewriter-text-tw">Yes! That puzzle wasn’t easy.</span></p></div></div></div><div id="comment">Yes! That puzzle wasn’t easy.</div>`;
(async()=>{for(const path of ['/daily','/daily/2026-11-25','/daily/','/daily-other','/lessons']){
 const dom=new JSDOM(html,{url:'https://www.chess.com'+path,runScripts:'outside-only'}),w=dom.window,d=w.document;
 Object.defineProperty(w.HTMLElement.prototype,'getClientRects',{value:()=>[{}]});
 try{w.eval(script);await new Promise(r=>setTimeout(r,180));const active=/^\/daily(?:\/|$)/.test(path);
 assert.equal(d.querySelector('.mko-toggle').hidden,!active,path);
 const translated=d.querySelector('p .mko-translation > span');assert.equal(!!translated,active,path);
 if(active){assert(!d.querySelector('.mko-toggle').textContent.includes('EN'));assert.match(translated.textContent,/[가-힣]/);assert.equal(d.querySelector('p .typewriter-text-tw').textContent,'Yes! That puzzle wasn’t easy.');assert.equal(d.querySelector('.coach-feedback-detail-text').textContent,'해결 되었습니다');console.log(path,translated.textContent);}
 assert.equal(d.querySelector('#comment').textContent,'Yes! That puzzle wasn’t easy.');assert.equal(d.querySelector('#comment').children.length,0);
 }finally{w.close();}
}console.log('PASS daily: current/date routes translate observed coach text; Korean label and comments preserved; unrelated routes inactive.');})().catch(e=>{console.error(e);process.exitCode=1;});
