function createCoachReporter(version) {
  const prefix='coach-ko-event:', memory=new Map(), states=new WeakMap(), streams=new Map();
  const available=typeof GM_getValue==='function' && typeof GM_listValues==='function';
  const get=(k,d)=>available?GM_getValue(k,d):(memory.has(k)?memory.get(k):d);
  const put=(k,v)=>available?GM_setValue(k,v):memory.set(k,v);
  const del=k=>available?GM_deleteValue(k):memory.delete(k);
  const keys=()=>available?GM_listValues():[...memory.keys()];
  const list=()=>keys().filter(k=>k.startsWith(prefix)).map(k=>get(k,null)).filter(Boolean);
  const clean=s=>String(s||'').slice(0,2000);
  let sending=false,lastError='',retryAt=0,failures=0;
  const validConfig=c=>c && /^https:\/\/script\.google\.com\/macros\/s\/[a-zA-Z0-9_-]+\/exec$/.test(c.endpoint) && /^[a-zA-Z0-9_-]{32,100}$/.test(c.token);
  function context(el,coach,evidence) {
    const screen=coachScreenContext(el);
    return {...screen,coach:coach||'Unknown',coachEvidence:evidence||(coach==='Unknown'?'canvas_identity_unavailable':coach?'avatar_image':'unavailable'),previous:null,next:null,sequence:'observed_only_not_game_history'};
  }
  function save(event) {
    const existing=get(prefix+event.id,null);
    if(!existing) {
      const all=list();
      if(all.length>=500){
        const sent=all.filter(e=>e.sentAt).sort((a,b)=>a.occurredAt.localeCompare(b.occurredAt));
        if(!sent.length){lastError='저장 공간 가득 참';return false;}
        del(prefix+sent[0].id);
      }
    }
    put(prefix+event.id,event);return true;
  }
  function make(source,translation,reason,kind,c) {
    const event={id:crypto.randomUUID(),occurredAt:new Date().toISOString(),kind,source:clean(source),translation:clean(translation),reason:String(reason||'').slice(0,250),version,context:c};
    return save(event)?event:null;
  }
  function observe(el,source,coach,entry,reason,evidence) {
    // Translated originals are intentionally hidden; their visible parent still
    // supplies context for the sentence before/after an untranslated message.
    if(!source || !(el.getClientRects().length || (el.classList.contains('mko-source-hidden') && el.parentElement?.getClientRects().length)))return;
    const route=location.pathname+location.search;
    let state=states.get(el);
    if(!state || state.source!==source || state.coach!==coach || state.route!==route){
      state={source,coach,route,since:Date.now(),committed:false};states.set(el,state);return;
    }
    if(state.committed || Date.now()-state.since<1200)return;
    state.committed=true;
    const streamKey=location.pathname+'|'+(el.matches('.move-feedback-speech-text-tw')?'review':'bubble');
    const prior=streams.get(streamKey);
    // A sentence repeated by a DOM remount is not another occurrence.
    if(prior && prior.source===source && prior.route===route && prior.coach===coach && Date.now()-prior.at<10000)return;
    const c=context(el,coach,evidence);
    const beforeMove=prior?.context?.moveHint.match(/URL move=(\d+)/)?.[1];
    const afterMove=c.moveHint.match(/URL move=(\d+)/)?.[1];
    const adjacent=beforeMove===undefined&&afterMove===undefined || beforeMove!==undefined&&afterMove!==undefined&&[0,1].includes(Number(afterMove)-Number(beforeMove));
    if(prior && prior.coach===coach && prior.context?.page===c.page && prior.context?.phase===c.phase && adjacent && Date.now()-prior.at<120000){
      c.previous=prior.source;
      if(prior.eventId){const previous=get(prefix+prior.eventId,null);if(previous&&!previous.sentAt){previous.context.next=clean(source);save(previous);}}
    }
    let event=null;
    if(!entry && /[a-zA-Z]{3}/.test(source) && source.length>=10 && source.length<=2000)event=make(source,'',reason,'untranslated',c);
    if(!entry && !event && /[a-zA-Z]{3}/.test(source) && source.length>=10 && source.length<=2000){state.committed=false;return;}
    streams.set(streamKey,{source,coach,route,context:c,at:Date.now(),eventId:event?.id});
    state.context=c;
  }
  function report(el,source,entry,coach,evidence,issue='unspecified',snapshot=null) {
    const state=states.get(el),c=snapshot||(state?.context && state.source===source && state.coach===coach && state.route===location.pathname+location.search?{...state.context}:context(el,coach,evidence));
    const category=['meaning','piece','perspective','display','identity','unspecified'].includes(issue)?issue:'unspecified';
    return make(source,entry?.ko||'','user_reported:'+category,'translation_report',c);
  }
  function openReport(el,source,entry,coach,evidence,onSaved) {
    if(document.getElementById('coach-ko-issue-panel'))return;
    const snapshot=context(el,coach,evidence);
    const dialog=document.createElement('dialog');dialog.id='coach-ko-issue-panel';dialog.style.cssText='max-width:400px;padding:20px;background:#262421;color:white;border:1px solid #888;border-radius:10px';
    const title=document.createElement('p');title.textContent='어떤 문제가 있나요?';dialog.append(title);
    for(const [kind,label] of [['meaning','의미·말투'],['piece','기물·체스 용어'],['perspective','나·상대 관점'],['display','말풍선 표시'],['identity','코치·화면 식별']]) {
      const b=document.createElement('button');b.textContent=label;b.style.cssText='margin:4px;padding:8px';b.onclick=()=>{if(report(el,source,entry,coach,evidence,kind,snapshot)){onSaved();dialog.close();}};dialog.append(b);
    }
    const close=document.createElement('button');close.textContent='취소';close.onclick=()=>dialog.close();dialog.append(close);dialog.addEventListener('close',()=>dialog.remove());document.body.append(dialog);dialog.showModal();
  }
  function send() {
    const config=get('coach-ko-reporter-config',null);
    if(sending || Date.now()<retryAt || !validConfig(config) || !config.enabled || typeof GM_xmlhttpRequest!=='function')return;
    const batch=list().filter(e=>!e.sentAt && Date.now()-Date.parse(e.occurredAt)>=5000).slice(0,20);
    while(batch.length>1 && JSON.stringify(batch).length>90000)batch.pop();
    if(!batch.length)return;
    sending=true;
    const fail=reason=>{sending=false;lastError=reason;failures++;retryAt=Date.now()+Math.min(3600000,30000*2**Math.min(failures,7));};
    // Only these fields leave the browser. No URL, account, cookies or raw DOM.
    const events=batch.map(({id,occurredAt,kind,source,translation,reason,version,context})=>({id,occurredAt,kind,source,translation,reason,version,context}));
    try { GM_xmlhttpRequest({method:'POST',url:config.endpoint,anonymous:true,timeout:25000,headers:{'Content-Type':'text/plain;charset=UTF-8'},data:JSON.stringify({schema:1,token:config.token,events}),
      onload(response){
        let reply;try{reply=JSON.parse(response.responseText);}catch(_){fail('응답 확인 실패');return;}
        if(response.status!==200 || reply.ok!==true || !Array.isArray(reply.accepted)){fail('전송 실패: '+String(reply.error||response.status).slice(0,40));return;}
        const accepted=new Set(reply.accepted);
        for(const event of batch)if(accepted.has(event.id)){const current=get(prefix+event.id,null);if(current){current.sentAt=new Date().toISOString();put(prefix+event.id,current);}}
        sending=false;failures=0;retryAt=0;lastError=accepted.size<batch.length?'일부 기록 미수신':'';
      },onerror(){fail('네트워크 오류');},ontimeout(){fail('전송 시간 초과');},onabort(){fail('전송 취소');}}); } catch(_) {fail('전송 권한 확인 필요');}
  }
  function download(){const url=URL.createObjectURL(new Blob([JSON.stringify({schema:1,version,records:list()},null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='coach-ko-context.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  function panel() {
    if(document.getElementById('coach-ko-report-panel'))return;
    const dialog=document.createElement('dialog');dialog.id='coach-ko-report-panel';dialog.style.cssText='max-width:440px;border:1px solid #888;border-radius:10px;padding:20px;background:#262421;color:white;font:14px/1.6 sans-serif';
    const title=document.createElement('strong');title.textContent='코치 오류 기록';dialog.append(title);
    const info=document.createElement('p');const all=list(),cfg=get('coach-ko-reporter-config',null);
    info.textContent='전송 대기 '+all.filter(e=>!e.sentAt).length+'건 · 최근 전송 완료 '+all.filter(e=>e.sentAt).length+'건. '+(cfg?.enabled?'자동 전송 켜짐.':'자동 전송 꺼짐 또는 미연결. ')+(lastError||'');dialog.append(info);
    const guide=document.createElement('p');guide.textContent='원문·번역·시각·화면·코치·전후 문구·수 번호 단서를 기록합니다. 비공개 시트의 연결 안내에서 이 브라우저를 연결하세요. 미번역은 자동 수집하며, 오역·표시 문제는 말풍선의 신고를 누르세요.';dialog.append(guide);
    const add=(label,fn)=>{const b=document.createElement('button');b.textContent=label;b.style.cssText='margin:4px;padding:6px 10px';b.onclick=fn;dialog.append(b);};
    add('기록 다운로드',download);
    if(validConfig(cfg)){add(cfg.enabled?'자동 전송 끄기':'자동 전송 켜기',()=>{put('coach-ko-reporter-config',{...cfg,enabled:!cfg.enabled});dialog.close();send();});add('지금 재시도',()=>{retryAt=0;send();dialog.close();});}
    add('닫기',()=>dialog.close());dialog.addEventListener('close',()=>dialog.remove());document.body.append(dialog);dialog.showModal();
  }
  function connect() {
    if(!location.hash.startsWith('#coach-ko-connect='))return;
    let config;
    try{config=JSON.parse(atob(location.hash.slice('#coach-ko-connect='.length)));}catch(_){return;}
    if(!validConfig(config))return;
    history.replaceState(null,'',location.pathname+location.search);
    if(!available){alert('Tampermonkey 스크립트를 먼저 최신 버전으로 업데이트해주세요.');return;}
    if(!confirm('코치 오류를 본인의 비공개 Google 시트로 자동 전송할까요?\n원문·번역·시각·화면·코치·전후 문구·수 번호 단서를 전송합니다. 계정 정보·대국 URL·쿠키는 전송하지 않습니다.\n수신처: '+config.endpoint))return;
    put('coach-ko-reporter-config',{endpoint:config.endpoint,token:config.token,enabled:true});
    make('Connection test','','browser_connected','connection_test',{page:'setup',coach:'Unknown',coachEvidence:'unavailable',moveHint:'unavailable',previous:null,next:null});
    alert('자동 전송을 연결했습니다. 잠시 후 비공개 시트에 연결 시험 기록이 추가됩니다.');
  }
  connect();window.addEventListener('hashchange',connect);
  if(typeof GM_registerMenuCommand==='function')GM_registerMenuCommand('코치 오류 기록 · 자동 전송 설정',panel);
  setInterval(send,30000);
  return {observe,report,openReport,panel,download,list,send,status(){const cfg=get('coach-ko-reporter-config',null),waiting=list().filter(e=>!e.sentAt).length;return lastError?'전송 확인':cfg?.enabled?'자동 기록 '+waiting:'기록 '+waiting;}};
}
