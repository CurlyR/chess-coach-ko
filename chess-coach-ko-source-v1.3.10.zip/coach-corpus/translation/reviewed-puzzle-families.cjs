// Assistant-authored exact sentences. No substring/fuzzy replacement at runtime.
const out={};
for(const [en,ko] of Object.entries({pawn:'폰',knight:'나이트',bishop:'비숍',rook:'룩',queen:'퀸'})){
 const object=ko+(ko==='나이트'?'를':'을');
 const pairs=[
  [`Can you find a way to win my ${en}?`,`제 ${object} 따낼 방법을 찾을 수 있나요?`],
  [`Oh no! You can win my ${en}!`,`이런! 제 ${object} 따낼 수 있겠네요!`],
  [`My ${en} is vulnerable. Do you see a way to win it?`,`제 ${ko}이 위험해요. 따낼 방법이 보이나요?`.replace('나이트이','나이트가')],
  [`I'll be in trouble if you capture my ${en}!`,`제 ${object} 잡으면 제가 곤란해지겠네요!`],
  [`Find a way to win a ${en}.`,`${object} 따낼 방법을 찾아보세요.`],
  [`Look at my ${en}. Anything you can do?`,`제 ${object} 보세요. 뭔가 할 수 있는 게 있나요?`],
  [`Take a careful look at the board. Do you see a way to win my ${en}?`,`판을 자세히 살펴보세요. 제 ${object} 따낼 방법이 보이나요?`],
  [`I blundered! You can win a ${en} from me!`,`제가 큰 실수를 했네요! 제 ${object} 따낼 수 있어요!`],
  [`Looks like my ${en} is in trouble. Do you see how?`,`제 ${ko}이 위험해 보이네요. 어떻게 공략할지 보이나요?`.replace('나이트이','나이트가')],
  [`I'm afraid you left your ${en} hanging.`,`아쉽지만 ${object} 공짜로 잡힐 수 있게 두셨어요.`],
  [`Try to win my ${en}. Do you see how?`,`제 ${object} 따내 보세요. 방법이 보이나요?`],
  [`Oops! That's a blunder by me. Can you figure out how to win my ${en}?`,`아차, 제가 큰 실수를 했네요. 제 ${object} 따낼 방법을 알아낼 수 있나요?`],
  [`Calculate correctly and you'll win my ${en}.`,`정확히 계산하면 제 ${object} 따낼 수 있어요.`],
  [`You're in a critical position. Find a way to win my ${en}.`,`중요한 국면이에요. 제 ${object} 따낼 방법을 찾아보세요.`],
  [`This lets me capture your ${en}. And after all trades I'll be the one winning material.`,`이 수를 두면 제가 당신의 ${object} 잡을 수 있어요. 교환이 모두 끝나면 기물 이득을 보는 쪽은 저예요.`],
  [`Block my attack on your ${en}.`,`당신의 ${object} 노리는 제 공격을 막아보세요.`],
  [`Get in the way of my attack on your ${en}.`,`당신의 ${object} 노리는 제 공격 경로를 막아보세요.`],
  [`This *blocks* an attack on a ${en}.`,`${object} 노리는 공격을 막는 수예요.`],
 ];
 for(const [source,target] of pairs)out[source]=target;
}
// Preserve wording already approved in earlier releases.
for(const file of ['reviewed-home-overrides.json','reviewed-audit-overrides.json']){
 for(const [en,ko] of Object.entries(require('./'+file)))if(en in out)out[en]=ko;
}
module.exports=out;
