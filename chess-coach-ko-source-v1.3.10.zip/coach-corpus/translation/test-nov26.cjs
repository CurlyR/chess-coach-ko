const fs=require('node:fs'),assert=require('node:assert/strict');
const {JSDOM}=require('./test-deps/node_modules/jsdom');
const script=fs.readFileSync(__dirname+'/coaches-ko.user.js','utf8');
const rows=require('./reported-nov26.json');
const cases=[...new Set(rows.flatMap(r=>[r.source,r.before,r.after]).filter(s=>/[a-zA-Z]{3}/.test(s)))];
const mixed='Fire on the board! 연속으로 12개를 맞추었습니다!';
cases.push(mixed);
const unknown='An unseen English sentence must remain visible. 연속으로 13개를 맞추었습니다!';
const dom=new JSDOM('<img class="bot-speech-avatar-and-wrapper-botImage" alt="Hikaru">',{url:'https://www.chess.com/analysis/game/live/1/review',runScripts:'outside-only'});
const w=dom.window,d=w.document;Object.defineProperty(w.HTMLElement.prototype,'getClientRects',{value:()=>[{}]});
const samples=[...cases,unknown].map(source=>{const shell=d.createElement('div');shell.className='bot-speech-content-botMessage';const text=d.createElement('span');text.className='typewriter-text-tw';text.textContent=source;shell.append(text);d.body.append(shell);return {source,shell,text};});
(async()=>{w.eval(script);for(const coach of ['Hikaru','Magnus']){d.querySelector('img').alt=coach;await new Promise(r=>setTimeout(r,450));const failures=[];for(const {source,shell,text} of samples){const translated=shell.querySelector('.mko-translation > span')?.textContent;
if(source===unknown){assert.equal(translated,undefined);assert(!text.classList.contains('mko-source-hidden'));continue;}
if(!translated||!/[가-힣]/.test(translated))failures.push(source);
assert.equal(text.textContent,source);
if(source===mixed)assert.equal(translated,'체스판 위에서 기세가 대단하네요! 연속으로 12개를 맞추었습니다!');
}assert.deepEqual(failures,[],coach+' untranslated');}
console.log(`PASS nov26: ${cases.length} reported/context/mixed-locale texts translated for both coaches; unknown English preserved.`);w.close();})().catch(e=>{console.error(e);w.close();process.exitCode=1;});
