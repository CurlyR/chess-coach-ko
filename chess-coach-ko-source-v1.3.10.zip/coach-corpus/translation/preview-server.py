from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
ROOT = Path(__file__).resolve().parent
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        files={'/game/123456789':('browser-preview.html','text/html; charset=utf-8'),'/game/live/demo':('browser-preview.html','text/html; charset=utf-8'),'/magnus-ko.user.js':('magnus-ko.user.js','text/javascript; charset=utf-8')}
        entry=files.get(self.path.split('?')[0])
        if not entry: self.send_error(404); return
        content=(ROOT/entry[0]).read_bytes()
        self.send_response(200);self.send_header('Content-Type',entry[1]);self.send_header('Content-Length',str(len(content)));self.end_headers();self.wfile.write(content)
HTTPServer(('127.0.0.1',8877),Handler).serve_forever()
