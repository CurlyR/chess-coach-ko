const fs=require('node:fs'),assert=require('node:assert/strict');
const {JSDOM}=require('./test-deps/node_modules/jsdom');
const source=fs.readFileSync(__dirname+'/magnus-ko.user.js','utf8');
const rows=fs.readFileSync(__dirname+'/Magnus_coach.ko.jsonl','utf8').trim().split(/\r?\n/).map(JSON.parse);
const excluded=JSON.parse(fs.readFileSync(__dirname+'/magnus-excluded.json','utf8'));
const first='Your opponent goes for e4, huh? Standard stuff, grabbing the center. Textbook.';
const second='You missed an opportunity to win a bishop through a fork.';
const dom=new JSDOM('<!doctype html><img class="bot-speech-avatar-and-wrapper-botImage" alt="Magnus"><div class="move-feedback-speech-text-component"><span class="move-feedback-speech-text-tw"><span></span></span></div>',{url:'https://www.chess.com/analysis/game/live/123/review',runScripts:'outside-only'});
const {window:w}=dom,d=w.document;
Object.defineProperty(w.HTMLElement.prototype,'getClientRects',{value:()=>[{}]});
const el=d.querySelector('.move-feedback-speech-text-tw');
const set=s=>{el.firstElementChild.textContent=s;};
const wait=()=>new Promise(r=>setTimeout(r,300));
(async()=>{
 set(first);w.eval(source);await wait();
 assert(d.querySelector('.mko-translation')?.textContent.includes('상대는 e4'));
 assert.equal(el.textContent,first,'original DOM remains untouched');
 d.querySelector('.mko-original').click();assert(d.querySelector('.mko-translation').textContent.includes(first));
 d.querySelector('.mko-toggle').click();assert(!el.classList.contains('mko-source-hidden'));assert(!d.querySelector('.mko-translation'));
 d.querySelector('.mko-toggle').click();await wait();assert(d.querySelector('.mko-translation'));
 set('unmatched English text');await wait();assert(!d.querySelector('.mko-translation'));assert(!el.classList.contains('mko-source-hidden'));
 set(excluded[0].source);await wait();assert(!d.querySelector('.mko-translation'));
 set(first);await wait();d.querySelector('img').alt='Levy';await wait();assert(!d.querySelector('.mko-translation'));
 d.querySelector('img').alt='Magnus';await wait();assert(d.querySelector('.mko-translation'));
 const hikaruRows=fs.readFileSync(__dirname+'/Hikaru_coach.ko.jsonl','utf8').trim().split(/\r?\n/).map(JSON.parse);
 const magnusSources=new Set(rows.map(r=>r.source));
 const h=hikaruRows.find(r=>!magnusSources.has(r.source)&&!r.issues?.length&&r.status!=='needs_context_review'&&!/[%{}*]/.test(r.source));
 assert(h,'Hikaru-specific test sample exists');d.querySelector('img').alt='Hikaru';set(h.source);await wait();
 assert(d.querySelector('.mko-translation')?.textContent.includes(h.ko.replace(/\*/g,'')),'Hikaru-only text translated');
 d.querySelector('img').alt='Magnus';await wait();assert(!d.querySelector('.mko-translation'),'coach change invalidates old translation');
 set('This is a stable unmatched coach sentence.');await new Promise(r=>setTimeout(r,3300));
 assert([...d.querySelectorAll('button')].some(b=>/기록 [1-9]/.test(b.textContent)),'diagnostic record accumulated');
 set('You get a chance to win a bishop through a fork.');await wait();assert(d.querySelector('.mko-translation')?.textContent.includes('포크로 비숍을 따낼 기회'));
 w.history.pushState({},'', '/lessons/test');await new Promise(r=>setTimeout(r,1100));assert(!d.querySelector('.mko-translation'));
 w.history.pushState({},'', '/play/coach');el.parentElement.remove();const shell=d.createElement('div');shell.className='bot-speech-content-botMessage';shell.style.backgroundColor='white';shell.style.padding='16px';const bubble=d.createElement('span');bubble.className='typewriter-text-tw';bubble.textContent=first;shell.append(bubble);d.body.append(shell);await wait();assert(d.querySelector('.mko-translation'));
 bubble.textContent='<img src=x onerror="alert(1)">';await wait();assert(!d.querySelector('.mko-translation'));assert.equal(d.querySelectorAll('img').length,1);
 w.history.pushState({},'', '/game/live/123456789');d.querySelector('img').remove();
 w.history.pushState({},'', '/game/123456789');
 const avatar=d.createElement('div');avatar.className='bot-speech-avatar-and-wrapper-botImage';avatar.append(d.createElement('canvas'));d.body.append(avatar);
 bubble.textContent='You saw a winning chance and took it! Let’s look at your game together.';await wait();
 assert(d.querySelector('.mko-translation')?.textContent.includes('승리할 기회를 놓치지 않았네요! 대국을 함께 살펴봐요.'));
 assert([...d.querySelectorAll('.mko-toggle')].every(e=>!e.hidden),'numeric game route displays status and diagnostics');
 const castle='Your opponent’s king can’t castle anymore? I mean, good for you, good for you. Their best option was to castle kingside.';
 for(const route of ['/analysis/game/live/123456789/review?move=28','/game/123456789']) {
   w.history.pushState({},'',route);bubble.textContent=castle;await wait();
   assert(d.querySelector('.mko-translation')?.textContent.includes('상대 킹이 이제 캐슬링할 수 없군요? 당신에게는 좋은 일이죠. 상대의 최선은 킹사이드 캐슬링이었어요.'));
   assert.equal(bubble.textContent,castle);
   bubble.textContent=castle+' A wholly unknown sentence for the regression.';await wait();
   assert(!d.querySelector('.mko-translation'),'unknown remainder must not be partially translated');
 }
 w.history.pushState({},'', '/game/live/123456789');
 bubble.textContent='You won with a nice tactic! Let’s look at it together.';await wait();
 assert(d.querySelector('.mko-translation')?.textContent.includes('멋진 전술로 승리했네요! 함께 살펴봐요.'));
 assert.equal(bubble.textContent,'You won with a nice tactic! Let’s look at it together.');assert(!shell.classList.contains('mko-source-hidden'));assert(shell.contains(d.querySelector('.mko-translation')));assert.equal(shell.style.backgroundColor,'white');
 bubble.textContent='Nice job controlling this game! You played an especially smart move worth reviewing.';await wait();
 assert(d.querySelector('.mko-translation')?.textContent.includes('경기를 잘 주도했어요!'));
 const resourceKey='Resource.test-account.coachesService.currentCoach';
 const resource=(name,timestamp=Date.now())=>JSON.stringify({timestamp,data:{currentCoach:{name}}});
 w.localStorage.setItem(resourceKey,resource('Hikaru'));bubble.textContent=h.source;await new Promise(r=>setTimeout(r,1100));
 assert(d.querySelector('.mko-toggle').textContent.startsWith('히카루'),'animated coach identified from committed resource');
 assert(shell.querySelector('.mko-translation')?.textContent.includes(h.ko.replace(/\*/g,'')));
 w.localStorage.setItem(resourceKey,resource('Magnus'));await new Promise(r=>setTimeout(r,1100));
 assert(d.querySelector('.mko-toggle').textContent.startsWith('매그너스'),'same-page coach changes detected');
 assert(!shell.querySelector('.mko-translation'),'old coach translation removed');
 w.localStorage.setItem(resourceKey,resource('Levy'));await new Promise(r=>setTimeout(r,1100));
 assert(d.querySelector('.mko-toggle').textContent.includes('대기'),'unsupported committed coach does not use Magnus/Hikaru');
 w.localStorage.setItem(resourceKey,resource('Magnus',w.performance.timeOrigin-1000));await new Promise(r=>setTimeout(r,1100));
 assert(!d.querySelector('.mko-toggle').textContent.startsWith('매그너스'),'historical cache ignored');
 w.localStorage.setItem(resourceKey,resource('Hikaru'));
 w.localStorage.setItem('Resource.other-account.coachesService.currentCoach',resource('Magnus'));await new Promise(r=>setTimeout(r,1100));
 assert(!/^(히카루|매그너스)/.test(d.querySelector('.mko-toggle').textContent),'ambiguous account resources ignored');
 w.localStorage.clear();
 const home=JSON.parse(fs.readFileSync(__dirname+'/received-untranslated-2026-11-18.json','utf8'));
 const reviewed=JSON.parse(fs.readFileSync(__dirname+'/reviewed-home-overrides.json','utf8'));
 const samples=home.map(row=>{const container=d.createElement('div');container.className='bot-speech-content-botMessage';const text=d.createElement('span');text.className='typewriter-text-tw';text.textContent=row.source;container.append(text);d.body.append(container);return {container,text,row};});
 for(const coach of ['Unknown','Magnus','Hikaru']) {
   if(coach!=='Unknown'){let img=d.querySelector('img');if(!img){img=d.createElement('img');img.className='bot-speech-avatar-and-wrapper-botImage';d.body.append(img);}img.alt=coach;}
   await wait();
   for(const {container,text,row} of samples){assert.equal(container.querySelector('.mko-translation > span')?.textContent,reviewed[row.source],coach+': '+row.source);assert.equal(text.textContent,row.source);}
 }
 for(const {container} of samples)container.remove();
 const audit=JSON.parse(fs.readFileSync(__dirname+'/reviewed-audit-overrides.json','utf8'));
 const auditSamples=Object.entries(audit).map(([en,ko])=>{const container=d.createElement('div');container.className='bot-speech-content-botMessage';const t=d.createElement('span');t.className='typewriter-text-tw';t.textContent=en;container.append(t);d.body.append(container);return {container,ko};});
 for(const name of ['Magnus','Hikaru']){d.querySelector('img').alt=name;await wait();for(const {container,ko} of auditSamples)assert.equal(container.querySelector('.mko-translation > span')?.textContent,ko);}
 for(const {container} of auditSamples)container.remove();
 const nov20={...require('./reviewed-puzzle-families.cjs'),...JSON.parse(fs.readFileSync(__dirname+'/reviewed-nov20-overrides.json','utf8'))};
 const newSamples=Object.entries(nov20).map(([en,ko])=>{const container=d.createElement('div');container.className='bot-speech-content-botMessage';const t=d.createElement('span');t.className='typewriter-text-tw';t.textContent=en;container.append(t);d.body.append(container);return {container,t,en,ko};});
 for(const name of ['Magnus','Hikaru','Unknown']){
   const img=d.querySelector('img');if(name==='Unknown')img.remove();else img.alt=name;
   await wait();
   for(const {container,t,en,ko} of newSamples){assert.equal(container.querySelector('.mko-translation > span')?.textContent,ko,name+': '+en);assert.equal(t.textContent,en,'original retained');}
 }
 const restored=d.createElement('img');restored.className='bot-speech-avatar-and-wrapper-botImage';restored.alt='Hikaru';d.body.append(restored);
 for(const {container} of newSamples)container.remove();
 console.log('PASS: '+newSamples.length+' directly reviewed November 20 sentences and piece variants under both coaches and Unknown.');
 bubble.textContent='You found the only move! You get a chance to win a rook through a fork.';await wait();
 assert.equal(shell.querySelector('.mko-translation > span')?.textContent,'유일한 수를 찾았네요! 포크로 룩을 따낼 기회가 생겼어요.','reviewed sentences compose');
 bubble.textContent='You found the only move! A completely unknown follow-up sentence.';await wait();assert(!shell.querySelector('.mko-translation'),'no partial translation');
 bubble.textContent='You found the only move! '+excluded[0].source;await wait();assert(!shell.querySelector('.mko-translation'),'excluded components remain English');
 d.querySelector('img').remove();avatar.remove();await wait();assert(!d.querySelector('.mko-translation'));assert(!d.querySelector('.mko-toggle').hidden);
 console.log('PASS: all 32 home records under Unknown/Magnus/Hikaru; reviewed composition; unknown/excluded component fallback.');
 console.log('PASS: previous regressions plus /game/live canvas-avatar popup, both reported messages, original preservation, visible idle status.');
 dom.window.close();
})().catch(e=>{console.error(e);dom.window.close();process.exitCode=1;});
