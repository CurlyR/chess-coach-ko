'use strict';
const templates=require('./reviewed-color-templates.json');
const output={};
const forms={White:['White','white','백'],Black:['Black','black','흑']};
const korean={White:'백',Black:'흑'};
for(const [source,target] of Object.entries(templates)){
 if(!/%(?:color|opposingColor)%/.test(source))throw new Error('Not a color template: '+source);
 if(/%[^%]+%|[{}]/.test(source.replace(/%(?:color|opposingColor)%/g,'')))throw new Error('Unsupported variable: '+source);
 const variables=s=>(s.match(/%(?:color|opposingColor)%/g)||[]).sort().join('|');
 if(variables(source)!==variables(target))throw new Error('Variable count mismatch: '+source);
 for(const color of ['White','Black']){
  const opposing=color==='White'?'Black':'White';
  for(const visible of forms[color])for(const oppositeVisible of forms[opposing]){
   const en=source.replaceAll('%color%',visible).replaceAll('%opposingColor%',oppositeVisible);
   const ko=target.replaceAll('%color%',korean[color]).replaceAll('%opposingColor%',korean[opposing]);
   if(output[en]&&output[en]!==ko)throw new Error('Conflicting color expansion: '+en);
   output[en]=ko;
  }
 }
}
module.exports=output;
