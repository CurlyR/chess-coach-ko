import json,re,pathlib
P=pathlib.Path(__file__).resolve().parent;ROOT=P.parent
groups=json.loads((ROOT/'common-review-groups.json').read_text(encoding='utf-8'))
piece_re=re.compile(r'\b(pawn|knight|bishop|rook|queen|piece)\b',re.I)
names=dict(pawn='폰',knight='나이트',bishop='비숍',rook='룩',queen='퀸',piece='기물')
preapproved=json.loads((P/'already-approved.json').read_text(encoding='utf-8'));out=dict(preapproved);audit=[]
entries={}
for f in sorted(P.glob('batch-*.txt')):
 start=int(f.stem.split('-')[1]);lines=f.read_text(encoding='utf-8').splitlines()
 for i,ko in enumerate(lines,start):
  assert i not in entries,('duplicate group',i)
  entries[i]=(ko,f.name,'direct')
families=json.loads((P/'family-templates.json').read_text(encoding='utf-8')) if (P/'family-templates.json').exists() else {}
for key,item in families.items():
 i=int(key)
 if i in entries:continue
 entries[i]=(item['template'],'family-templates.json:'+str(item['fromGroup']),'reviewed-family-expansion')
for i,(ko,decision,review_kind) in sorted(entries.items()):
  for source in groups[i]:
   rx=piece_re if review_kind=='reviewed-family-expansion' else re.compile(r'\b(pawn|knight|bishop|rook|queen)\b',re.I)
   pieces=[names[x.lower()] for x in rx.findall(source)]
   assert set(map(int,re.findall(r'\{(\d+)\}',ko)))==set(range(len(pieces))),(i,source,ko)
   result=ko
   for n,piece in enumerate(pieces):
    final=(ord(piece[-1])-0xAC00)%28!=0
    suffixes=[('으로','으로','로'),('이나','이나','나'),('이네요','이네요','네요'),('이에요','이에요','예요'),('이군요','이군요','군요'),('이라니','이라니','라니'),('이죠','이죠','죠'),('이거든요','이거든요','거든요'),('이잖아요','이잖아요','잖아요'),('이요','이요','요'),('인가요','인가요','인가요'),('일까요','일까요','일까요'),('을','을','를'),('이','이','가'),('은','은','는'),('과','과','와')]
    for suffix,yes,no in suffixes:result=result.replace('{'+str(n)+'}'+suffix,piece+(yes if final else no))
    result=result.replace('{'+str(n)+'}',piece)
   result=preapproved.get(source,result)
   out[source]=result;audit.append({'group':i,'source':source,'ko':result,'decision':decision,'reviewKind':review_kind})
(ROOT/'reviewed-common-overrides.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(P/'decisions.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
total=sum(map(len,groups));progress={'total':total,'directReviewed':sum(x['reviewKind']=='direct' for x in audit),'familyExpanded':sum(x['reviewKind']=='reviewed-family-expansion' for x in audit),'approvedTotal':len(out),'remaining':total-len(out),'reviewedGroups':len(set(x['group'] for x in audit)),'published':False}
(P/'progress.json').write_text(json.dumps(progress,indent=2)+'\n',encoding='utf-8');print(json.dumps(progress))
