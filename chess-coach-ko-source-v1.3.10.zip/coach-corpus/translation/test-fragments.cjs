const fs=require('node:fs'),assert=require('node:assert/strict');
const {JSDOM}=require('./test-deps/node_modules/jsdom');
let code=fs.readFileSync(__dirname+'/coaches-ko.user.js','utf8');
const marker=code.lastIndexOf('\n})();');
code=code.slice(0,marker)+'\nwindow.fragmentTest={lookup,lookupUnit,fragmentPackages};'+code.slice(marker);
const dom=new JSDOM('<img class="bot-speech-avatar-and-wrapper-botImage" alt="Hikaru"><div class="bot-speech-content-botMessage" style="background:white;color:#312e2b"><span class="typewriter-text-tw"></span></div>',{url:'https://www.chess.com/analysis/game/live/123/review',runScripts:'outside-only'});
const w=dom.window,d=w.document;Object.defineProperty(w.HTMLElement.prototype,'getClientRects',{value:()=>[{}]});w.eval(code);
const {lookup,fragmentPackages}=w.fragmentTest;
let count=0;
for(const coach of ['Magnus','Hikaru'])for(const prefix of Object.keys(fragmentPackages[coach].prefixes))for(const tail of Object.keys(fragmentPackages[coach].tails)){
 const r=lookup(prefix+' '+tail,coach);assert(r.entry?.reviewed,coach+': '+prefix+' '+tail);assert(!/[a-zA-Z{}%]/.test(r.entry.ko),r.entry.ko);count++;
}
const check=(source,expected)=>{for(const c of ['Magnus','Hikaru','Unknown'])assert.equal(lookup(source,c).entry?.ko,expected,c+': '+source);};
check('Their better move was to castle queenside.','상대가 두었어야 할 더 좋은 수는 퀸사이드 캐슬링을 하는 것이었어요.');
check('My best option was to capture a bishop.','제 최선의 선택은 비숍을 잡는 것이었어요.');
check('They missed a chance to promote a pawn to a queen.','상대는 폰을 퀸으로 승격할 기회를 놓쳤어요.');
check('This prevents the opponent from being able to attack the queen with a pawn.','이 수는 상대가 폰으로 퀸을 공격하는 것을 막아요.');
check('Their best option was to fork the king and the queen with a knight.','상대의 최선은 나이트로 킹과 퀸을 포크로 공격하는 것이었어요.');
for(const c of ['Magnus','Unknown'])assert.equal(lookup('Your better option was to force White to trade into a lost endgame.',c).entry?.ko,'당신의 더 좋은 선택은 백이 지는 엔드게임으로 교환하도록 강제하는 것이었어요.');
assert(!lookup('Your better option was to force White to trade into a lost endgame.','Hikaru').entry,'coach-specific fragment must not leak');
for(const source of ['Their best option was to castle kingside. unknown tail','Their best option was to invent a new move.','Their best option was to castle king','Fake prefix castle kingside.','Their best option was to castle kingside. An unknown trailing sentence.'])assert(!lookup(source,'Hikaru').entry,source);
const composite='Your opponent’s king can’t castle anymore? I mean, good for you, good for you. Their better move was to castle queenside.';
assert(lookup(composite.replace(/[‘’]/g,"'"),'Hikaru').entry.ko.endsWith('퀸사이드 캐슬링을 하는 것이었어요.'));
// Unknown identity must not silently select conflicting fragment translations.
const old=fragmentPackages.Magnus.tails['castle queenside.'];fragmentPackages.Magnus.tails['castle queenside.']='다른 뜻이 되는';assert(!lookup('Their better move was to castle queenside.','Unknown').entry);fragmentPackages.Magnus.tails['castle queenside.']=old;
const loading=require('./loading-phrases-source.json');
for(const source of loading)for(const c of ['Magnus','Hikaru','Unknown'])assert(lookup(source.replace(/[‘’]/g,"'").replace(/[“”]/g,'"'),c).entry?.reviewed,source);
const el=d.querySelector('.typewriter-text-tw'),wait=()=>new Promise(r=>setTimeout(r,180));
(async()=>{
 for(const source of [composite,'World Champion Mikhail Tal only had 3 fingers on his right hand.']){
  el.textContent=source;await wait();assert(d.querySelector('.mko-translation'));assert.equal(el.textContent,source);assert.equal(el.parentElement.style.background,'white');
 }
 assert(d.querySelector('.mko-translation').textContent.includes('미하일 탈은 오른손 손가락이 세 개'));
 console.log(`PASS fragments: ${count} prefix/action pairs; actor, promotion, piece roles, grammar, ambiguous/unknown/partial fallback; 58 loading phrases and popup DOM.`);w.close();
})().catch(e=>{console.error(e);w.close();process.exitCode=1;});
