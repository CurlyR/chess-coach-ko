'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const {JSDOM}=require('./test-deps/node_modules/jsdom');
const script=fs.readFileSync(__dirname+'/coaches-ko.user.js','utf8');
const packages=JSON.parse(script.split('const packages = ')[1].split(/\r?\n/,1)[0].replace(/;$/,''));
const normalize=s=>s.normalize('NFC').replace(/\*/g,'').replace(/[‘’]/g,"'").replace(/[“”]/g,'"').replace(/\s+/g,' ').trim();
const plain=require('./reviewed-full-pass-overrides.json');
const colors=require('./expand-reviewed-colors.cjs');
const expected={...colors,...plain,...require('./reviewed-nov24-overrides.json')};
for(const name of ['Magnus','Hikaru']){
 const entries=new Map(packages[name].entries.map(([s,ko,reviewed])=>[s,{ko,reviewed}]));
 for(const [en,ko] of Object.entries(expected)){
  assert.deepEqual(entries.get(normalize(en)),{ko,reviewed:true},name+': '+en);
  assert(!/%[A-Za-z_]+%/.test(ko),'no unresolved variables');
 }
}
assert.equal(colors['White lost their winning advantage and now Black has the better position.'],'백 측이 승세를 놓쳐 이제 흑 측이 더 좋은 국면이에요.');
assert.equal(colors['Black lost their winning advantage and now White has the better position.'],'흑 측이 승세를 놓쳐 이제 백 측이 더 좋은 국면이에요.');
assert.equal(colors['White lost their winning advantage and now White has the better position.'],undefined,'never expand to identical opposing colors');
const cases=[
 '*Pinning* the piece, huh? Adding pressure. We’ll see if it works.',
 'Your bishop is vulnerable, but you can pin one of my attackers.',
 'Your defender is now pinned, allowing me to capture your queen.',
 'Bb5 develops the bishop and pins the knight on c6.',
 'Bg5 develops a bishop to attack the knight on f6.',
 'Qf6 develops the queen, attacks the knight on c6 and threatens Qxf2#.',
 'Nce7retreats the knight to a safe square.',
 'Nd4 centralizes the knight and protects the с5 pawn.',
 'White was in trouble, but managed to win on time. That’s some serious survival!',
 'Black will have a winning position, finished off by the clock.',
 'White lost their winning advantage and now Black has the better position.',
 '흑 lost their winning advantage and now 백 has the better position.',
 'By moving with tempo, Black will secure the knight on the next move.',
 'That will be a strong *discovery* and White will win a bishop.'
];
const dom=new JSDOM('<!doctype html><img class="bot-speech-avatar-and-wrapper-botImage" alt="Magnus"><div class="bot-speech-avatar-and-wrapper-botImage"><canvas></canvas></div>',{url:'https://www.chess.com/puzzles/rated',runScripts:'outside-only'});
const w=dom.window,d=w.document;Object.defineProperty(w.HTMLElement.prototype,'getClientRects',{value:()=>[{}]});
const elements=cases.map(en=>{const shell=d.createElement('div');shell.className='bot-speech-content-botMessage';const text=d.createElement('span');text.className='typewriter-text-tw';text.textContent=en;shell.append(text);d.body.append(shell);return {en,text,shell};});
const wait=()=>new Promise(r=>setTimeout(r,350));
(async()=>{
 w.eval(script);
 for(const name of ['Magnus','Hikaru','Unknown']){
  if(name==='Unknown')d.querySelector('img').remove();else d.querySelector('img').alt=name;
  await wait();
  for(const {en,text,shell} of elements){assert.equal(shell.querySelector('.mko-translation > span')?.textContent,expected[en],name+': '+en);assert.equal(text.textContent,en);}
 }
 const first=elements[0];first.shell.querySelector('.mko-original').click();assert.equal(first.shell.querySelector('.mko-translation > span').textContent,first.en.replace(/\*/g,''),'original toggle shows source text with emphasis rendered');
 console.log('PASS: '+Object.keys(expected).length+' exact reviewed entries per coach; opposing color correctness; notation, pin ownership, time win, source typo and Unknown DOM regressions.');
 w.close();
})().catch(e=>{console.error(e);w.close();process.exitCode=1;});
