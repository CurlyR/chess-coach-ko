const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=__dirname;
const assets=require('./fragment-assets.json'),families=require('./fragment-families-source.json'),prefixes=require('./fragment-prefixes-ko.json');
const translations=new Map(fs.readFileSync(path.join(root,'fragment-families-ko.txt'),'utf8').trim().split(/\r?\n/).map(line=>{const i=line.indexOf('|');return [Number(line.slice(0,i)),line.slice(i+1)];}));
assert.equal(translations.size,families.length);
const pieceNames={bishop:'비숍',knight:'나이트',pawn:'폰',queen:'퀸',rook:'룩',piece:'기물'};
const normalize=s=>s.normalize('NFC').replace(/\*/g,'').replace(/[‘’]/g,"'").replace(/[“”]/g,'"').replace(/\s+/g,' ').trim();
function particles(s){return s.replace(/(\{\d+\}|비숍|나이트|폰|퀸|룩|기물)(으로|을|과|이)/g,(all,n,p)=>{const final=(n.charCodeAt(n.length-1)-44032)%28;return n+({으로:(!final||final===8)?'로':'으로',을:final?'을':'를',과:final?'과':'와',이:final?'이':'가'}[p]);});}
const result={};
for(const [coach,rows] of Object.entries(assets)){
 const tails={},heads={};
 for(const [key,raw] of Object.entries(rows)){
  const en=normalize(raw);
  if(key.includes('-Circumstance-')){assert(prefixes[en],`Missing prefix ${key}: ${en}`);heads[en]=prefixes[en];continue;}
  const pieces=[];const family=en.replace(/\b(bishop|knight|pawn|queen|rook|piece)\b/g,p=>{pieces.push(p);return '{piece}';});
  const index=families.indexOf(family);assert(index>=0,`Missing family: ${en}`);
  let ko=translations.get(index);const used=[...ko.matchAll(/\{(\d+)\}/g)].map(m=>+m[1]);
  assert.deepEqual([...new Set(used)].sort(),pieces.map((_,i)=>i),`Piece roles: ${family}`);
  ko=particles(ko.replace(/\{(\d+)\}/g,(_,i)=>pieceNames[pieces[+i]]));
  assert(ko.endsWith('는'),`Expected Korean attributive form: ${ko}`);
  const variants=en.includes('%opposingColor%')?[['White','백'],['Black','흑']]:[[null,null]];
  for(const [color,label] of variants){const source=color?en.replaceAll('%opposingColor%',color):en;const target=color?ko.replaceAll('%opposingColor%',label):ko;assert(!/[{}%]/.test(target),target);if(tails[source])assert.equal(tails[source],target);tails[source]=target;}
 }
 result[coach]={prefixes:heads,tails};
}
fs.writeFileSync(path.join(root,'fragments-generated.json'),JSON.stringify(result,null,2)+'\n');
console.log('Fragment coverage:',JSON.stringify(Object.fromEntries(Object.entries(result).map(([c,p])=>[c,{prefixes:Object.keys(p.prefixes).length,tails:Object.keys(p.tails).length}]))));
module.exports=result;
