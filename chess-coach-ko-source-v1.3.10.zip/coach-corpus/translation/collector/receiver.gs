// Private Apps Script project. Never upload the configured copy to GitHub.
const SHEET_ID = '__PRIVATE_SHEET_ID__';
const REPORT_TOKEN = '__PRIVATE_TOKEN__';
function jsonReply(value) {
  return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);
}
function doGet() { return jsonReply({service:'coach-ko-reports',schema:1}); }
function clean(value, max) {
  const s=String(value==null?'':value).slice(0,max);
  return /^[=+@\-]/.test(s)?"'"+s:s;
}
function doPost(e) {
  let body;
  try {
    if(!e || !e.postData || e.postData.contents.length>150000) return jsonReply({ok:false,error:'size'});
    body=JSON.parse(e.postData.contents);
    if(body.token!==REPORT_TOKEN)return jsonReply({ok:false,error:'unauthorized'});
    if(body.schema!==1 || !Array.isArray(body.events) || body.events.length>20)return jsonReply({ok:false,error:'schema'});
  } catch(_) {return jsonReply({ok:false,error:'json'});}
  const lock=LockService.getScriptLock();
  if(!lock.tryLock(10000))return jsonReply({ok:false,error:'busy'});
  try {
    const sheet=SpreadsheetApp.openById(SHEET_ID).getSheetByName('오류 기록');
    const last=sheet.getLastRow();
    if(last>=20000)return jsonReply({ok:false,error:'storage_full'});
    const ids=new Set(last>1?sheet.getRange(2,14,last-1,1).getValues().flat():[]);
    const accepted=[],rows=[];
    for(const ev of body.events) {
      if(!ev || !/^[a-zA-Z0-9-]{16,80}$/.test(ev.id) || !['untranslated','translation_report','connection_test'].includes(ev.kind))continue;
      if(ids.has(ev.id)){accepted.push(ev.id);continue;}
      if(typeof ev.source!=='string' || ev.source.length>2000)continue;
      const c=ev.context||{};
      rows.push([new Date(),clean(ev.occurredAt,32),clean(ev.kind,30),clean(ev.source,2000),clean(ev.translation,2000),clean(ev.reason,250),clean(c.page,40),clean(c.coach,30),clean(c.coachEvidence,60),clean(c.moveHint,80),clean(c.previous,2000),clean(c.next,2000),clean(ev.version,20),ev.id,clean(c.playType,40),clean(c.phase,40),clean(c.messageSurface,40),clean(c.screenEvidence,80),clean(c.sequence,60)]);
      ids.add(ev.id);accepted.push(ev.id);
    }
    if(rows.length){
      sheet.getRange(last+1,1,rows.length,19).setValues(rows);
      sheet.getRange(last+1,1,rows.length,1).setNumberFormat('yyyy-mm-dd hh:mm:ss');
      sheet.getRange(last+1,1,rows.length,19).setWrap(true).setVerticalAlignment('top');
    }
    return jsonReply({ok:true,accepted});
  } catch(_) {return jsonReply({ok:false,error:'storage'});}
  finally {lock.releaseLock();}
}
