const fs=require('node:fs'),assert=require('node:assert/strict');
const {JSDOM}=require('./test-deps/node_modules/jsdom');
const source=fs.readFileSync(__dirname+'/coaches-ko.user.js','utf8');
const packages=JSON.parse(source.split('const packages = ')[1].split(/\r?\n/)[0].replace(/;$/,''));
const common=require('./reviewed-common-overrides.json'),previous=require('./common-review/preexisting-reviewed-packages.json');
const norm=s=>s.normalize('NFC').replace(/\*/g,'').replace(/[‘’]/g,"'").replace(/[“”]/g,'"').replace(/\s+/g,' ').trim();
const queue=require('./common-review-groups.json').flat();
assert.equal(queue.length,10593);
assert.equal(queue.filter(en=>!Object.hasOwn(common,en)).length,0,'complete fixed review queue');
assert.equal(require('./common-review/progress.json').remaining,0);
for(const name of ['Magnus','Hikaru']){
 const dict=new Map(packages[name].entries.map(([s,ko,rv])=>[s,{ko,rv}]));
 for(const [en,ko] of Object.entries(common)){const entry=dict.get(norm(en));assert(entry?.rv,name+': '+en);assert(!/[{}]|%[A-Za-z_]+%/.test(entry.ko),'unresolved slot');}
 for(const [en,ko] of previous[name])assert.deepEqual(dict.get(en),{ko,rv:true},'preserve approved '+name+': '+en);
}
const cases={
 "Your opponent's bishop is pinned, making it useless as a defender.":'상대의 비숍이 핀에 걸려 수비 역할을 할 수 없어요.',
 'You captured the bishop and defended your piece at the same time.':'비숍을 잡으면서 자신의 기물도 동시에 지켰어요.',
 'Your opponent can make a capture, and your pinned bishop would be unable to help.':'상대가 기물을 잡아도 핀에 걸린 당신의 비숍은 도울 수 없어요.',
 'Your knight is no longer pinned and can now join the defense.':'당신의 나이트의 핀이 풀려 이제 수비에 참여할 수 있어요.',
 'You missed a chance to win a queen, but your position would still be losing.':'퀸을 따낼 기회를 놓쳤지만, 그렇게 했어도 여전히 지는 국면이었어요.',
 'They captured your rook and kept their own vulnerable piece defended.':'상대가 당신의 룩을 잡으면서 위험에 놓인 자신의 기물도 계속 지켰어요.'
};
const dom=new JSDOM('<img class="bot-speech-avatar-and-wrapper-botImage" alt="Magnus">',{url:'https://www.chess.com/analysis/game/live/1/review',runScripts:'outside-only'});
const w=dom.window,d=w.document;Object.defineProperty(w.HTMLElement.prototype,'getClientRects',{value:()=>[{}]});
const bubbles=Object.entries(cases).map(([en,ko])=>{const shell=d.createElement('div');shell.className='bot-speech-content-botMessage';const text=d.createElement('span');text.className='typewriter-text-tw';text.textContent=en;shell.append(text);d.body.append(shell);return {shell,text,en,ko};});
(async()=>{w.eval(source);for(const name of ['Magnus','Hikaru']){d.querySelector('img').alt=name;await new Promise(r=>setTimeout(r,350));for(const {shell,text,en,ko} of bubbles){assert.equal(shell.querySelector('.mko-translation > span')?.textContent,ko);assert.equal(text.textContent,en);}}w.close();console.log('PASS common: '+Object.keys(common).length+' reviewed entries enabled for both coaches; previous approvals preserved; ownership, pinned defender, material balance and particles.');})().catch(e=>{console.error(e);w.close();process.exitCode=1;});
